
<?php
include("cursor.php");
//include database file
include("ussd_session.php");
include("Employee.php");
include("pini.php");
include("yo.php");
include("sms.php");
include("Settings.php");
class proccess

{
    //ussd variable
     private $transactionId;
     private $transactionTime;
     private $msisdn;
     private $requestString;
     private $user_session;
	 private $last_usercode;
	//  private $oldpin;




	//  public function __construct()
    // {
	// 	$ussd_session=new session();

    // }
	//  public function __construct()
    // {
	// 	$employee=new Employee();

    // }

	private function performActivateAccountProcess()
	{
		//Lets validate the PIN
		$oldpin = $this->requestString;
		
		if($this->user_session == null){
			$this->sessionError();
			return;
		}
		$mobile = $this->formatMobile($this->msisdn);
		$pini=new pin();
		if($pini->validatePin($mobile,$oldpin)==0){
		
			$this->sessionErrorIncorrectPin();
			return;
		}
		//Lets vaidate the PIN
		// if(!$this->validatePin($pin)){
		// 	$this->promptActivateAccount(true);
		// 	return;
		// }
		$ussd_session=new ussd_session();
		//Lets prompt for a new PIN
		$data['last_usercode'] = 'ACT_PROMPT_02';
		$ussd_session->update($data, $this->transactionId);
		
		$menu_text = "Please enter a new PIN";
		$this->writeResponse($menu_text);
	}

//  
      private function promptActivateAccount($is_error = false)
    {
		//We need to create the session
		if($is_error == false)
		{
			$ussd_session=new ussd_session();
			$data['transaction_id'] = $this->transactionId;
			$data['msisdn'] = $this->msisdn;
			$data['last_usercode'] = 'ACT_PROMPT_01';
			
			$ussd_session->insert($data);
			$menu_text = "Welcome to CreditPlus\r\nPlease enter your activation code";
		}
		else
		{
			$data['last_usercode'] = 'ACT_PROMPT_01';
			// $this->ussd_session->update($this->user_session->id,$data);
			
			$menu_text = "Activation code is incorrect, please enter the correct code to activate";
		}
		
		
		$this->writeResponse($menu_text);
	}

	
public function process()
    {
		$proceed = $this->validate_request(); //found
		
		if(!$proceed)
			return;
		
		
		if(isset($_GET['response']) && $_GET['response'] == 'false')
		 {
			if($this->checkIfActivated())
            {
				if($this->checkIfSuspended()==2)
				{
					$this->writeResponse("Welcome to CreditPlus\r\nYour account has been suspended by your employer",true);
				}
				else
				{
					$this->welcome();
				}
			
            }
            
		
			else
			{
                
			$this->promptActivateAccount();
			}




		}
		
		
		else{
			
			//Lets get the session and see what the last response was
				// $this->writeResponse($this->transactionId,true);

			$ussd_session=new ussd_session();
			$this->user_session = $ussd_session->getByTransactionId($this->transactionId);
	// $this->writeResponse($this->user_session,true);
			if($this->user_session == null)
			{
				$this->sessionError();
				return;
			}
			
			$code = $this->user_session;
			$this->last_usercode = $code;
			//Lets validate if we have a correct request string
			
			$this->requestString = $_GET['ussdRequestString'];
			
			if($this->requestString == "*")
			{
				$this->goBack();
			}
			else
			{
				switch($code){
					case '00':
						//lets analyse the current urequest string
						if($this->requestString == '1'){
							$this->getAdvance();
								// $this->writeResponse('trying to get advance',true);

						}else if($this->requestString == '2'){
							$this->getAccountStatus();
							// $this->writeResponse('trying to get account status',true);
						}else if($this->requestString == '3'){
							// $this->writeResponse('trying get ative advances',true);
							$this->getActiveAdvances();
						}else if($this->requestString == '4'){
							// $this->writeResponse('trying to reset pin',true);
							$this->resetPin();
						}
						else
						{
							$this->welcome_general(true);
						}
						break;
					case '00_01':
						$this->getAdvancePinRequest();
						break;
					case '00_01_00':
						$this->getAdvanceProcess();
						break;
					case '00_02':
						$this->getAccountStatusProcess();
						break;
					case '00_03':
						$this->getActiveAdvancesProcess();
						break;
					case '00_04':
					$this->resetPinValidate();
						break;
					case '00_04_00':
						$this->resetPinProcess();
						break;
					case 'ACT_PROMPT_01':
						$this->performActivateAccountProcess();
						break;
					case 'ACT_PROMPT_02':
						$this->resetPinProcess();
						break;
					// case 'ACT_PROMPT_01_02':
					// 	$this->promptActivateAccount(true);
					// 	break;
				}
			}
		}
    }




	private function validate_request()
    {
		//Lets check for the correct parameters
		
		
		//transaction id
		if (!isset($_GET['transactionId'])) {
			
			$this->writeResponse( 'Transactionid not found',true);
			return false;
		}
		
		$this->transactionId = $_GET['transactionId']; //available
		
		// //Transaction time
		if (!isset($_GET['transactionTime'])) {
			$this->writeResponse('Transactiontime not found',true);
			return false;
		}
		
		$this->transactionTime = $_GET['transactionTime'];
		
		// //msisdn
		if (!isset($_GET['msisdn'])) {
			
			$this->writeResponse('msisdn not found',true);
			
			return false;
		}
		
		else{
			//check if the number is registered with creditplus
			$msisdn = $_GET['msisdn'];
			//we need to strip off the 256 and append a 0
			$mobile = $this->formatMobile($msisdn);
            // $mobile="0772093837";
			$employeei=new Employee();
			$employee = $employeei->getByMobile($mobile);
			//  $employee=null;
			if($employee == null){
				
				$this->writeResponse("Sorry, your number is not registered on the CreditPlus\r\nPlease visit www.creditplus.ug for help",true);
				return false;
			}
			// $this->writeResponse("retuned true",true);
			$this->msisdn = $mobile;
		}
		
		return true;
		
	}
// //method to check if the number is activated
     private function checkIfActivated()
    {

		$mobile = $this->formatMobile($this->msisdn);
            // $mobile="0772093837";
			$employeei=new Employee();
			$employee = $employeei->getByMobile($mobile);
	
		//lets get the user and check if activated
		$user = $employeei->isActive($mobile);
        // $user=null;
	
		if($user == null){
			// $this->writeResponse("your mobile is not Activated \n contact credit plus",true);
			return false ;
		}
		// user active now
 
		if($user == '1')
		{
		return true;
		}
	
		
	}

	private function formatMobile($mobile){
		$length = strlen($mobile);
		$m = '0';
		//format 1: +256752665888
		if($length == 13)
			return $m .= substr($mobile, 4);
		elseif($length == 12)
			return $m .= substr($mobile, 3);
		elseif($length == 9)
			return $m .= $mobile;
			
		return $mobile;
	}
	
	private function formatMobileInternational($mobile){
		$length = strlen($mobile);
		$m = '+256';
		//format 1: +256752665888
		if($length == 13)
			return $mobile;
		elseif($length == 12) //format 2: 256752665888
			return "+".$mobile;
		elseif($length == 10) //format 3: 0752665888
			return $m .= substr($mobile, 1);
		elseif($length == 9) //format 4: 752665888
			return $m .= $mobile;
			
		return $mobile;
	}
	
	private function formatMobileInternational256($mobile){
		$length = strlen($mobile);
		$m = '256';
		//format 1: +256752665888
		if($length == 13)
			return $mobile;
		elseif($length == 12) //format 2: 256752665888
			return "+".$mobile;
		elseif($length == 10) //format 3: 0752665888
			return $m .= substr($mobile, 1);
		elseif($length == 9) //format 4: 752665888
			return $m .= $mobile;
			
		return $mobile;
	}
	
	private function checkNetwork($mobile)
	{
		$network = "none";
		$m = $this->formatMobile($mobile);
		$prefix = substr($m,0,3);
		
		if($prefix == "075" || $prefix == "070") //check for airtel
			$network = "airtel";
		else if($prefix == "077" || $prefix == "078") //check for mtn
			$network = "mtn";
		else if($prefix == "079") //check for africell
			$network = "africell";
		else if($prefix == "071")//check for utl
			$network = "utl";
		
		return $network;
	}

	private function goBack()
	{
		$this->welcome_general(true);
		switch($this->last_usercode)
        {
			case '00_01':
			case '00_02':
			case '00_03':
			case 'ACT_PROMPT_02':
				$this->welcome_general(true);
				break;
				case '00_04':
				$this->welcome_general(true);
				break;
			
		}
		
		
		
	}


private function welcome_general($from_activation = true)
{
//We need to create the session
	$ussd_session=new ussd_session();
	if($from_activation == true)
	{

		$data['last_usercode'] = '00';

		$ussd_session->update($data, $this->transactionId);
	}
	else
	{

    
		$data['transaction_id'] = $this->transactionId;
		$data['msisdn'] = $this->msisdn;
		$data['last_usercode'] = '00';

	    $ussd_session->insert($data);
	}


	$menu_text = "Welcome to CreditPlus\r\n1. Request Advance\r\n2. Account Status\r\n3. Advance Statement\r\n4. Change PIN";
	$this->writeResponse($menu_text);
}
    
		
		
     
private function writeResponse($msg,$isend = false)
{
	$resp_msg = 'responseString='.urlencode($msg);
	if($isend)
	$resp_msg .= '&action=end';
	else
	$resp_msg .= '&action=request';
	echo $resp_msg;
}

private function checkIfSuspended()
{
	$mobile = $this->formatMobile($this->msisdn);
	$employeei=new Employee();

	$employee=$employeei->getByMobile($mobile);
	if($employee == null)
	{
	
		$this->writeResponse("Employee not found, please contact CreditPlus for help",true);
		return;

	}

$status=$employeei->employeeStatus($mobile);
	if($status == 2)
	return 2;
	else    
	return false;
}


private function welcome()
{
	$this->welcome_general(false);
}

  private function getAdvance(){
		//we need to show how much the employee can borrow
		$msisdn = $_GET['msisdn'];
		//we need to strip off the 256 and append a 0
		$mobile = $this->formatMobile($msisdn);
		// $mobile="0772093837";
		$employeei=new Employee();
		$employee = $employeei->getByMobile($mobile);
		if($employee == null)
		{
			$this->writeResponse("Employee not found, please contact CreditPlus for help",true);
			return;
		}
		
		
		$current_bal=$employeei->getTotalBorrowed($mobile);
				
		//we need to check if the amount requested is greater than the advance limit
		// $advance_limit_perc = $employer->advance_limit;
		$advance_limit = $employeei->advanceLimitAmount($mobile);

		
		//Lets update the session data
		$ussd_session=new ussd_session();
			
		$data['last_usercode'] = '00_01';
		
		$ussd_session->update($data,$this->transactionId);
		
		$available_amount = $advance_limit - $current_bal ;
		
		if($available_amount > 0)
		{
			$menu_text = "Available amount is UGX".number_format($available_amount)."\r\n";
			$menu_text .= "Please specify the amount";
		}
		else
		{
			$menu_text = "Advance limit has been reached\r\n*. Back";
		}
		
		$this->writeResponse($menu_text);
		
	}

	private function resetPin(){
		$ussd_session=new ussd_session();
		$data['last_usercode'] = '00_04';
		

		$ussd_session->update($data,$this->transactionId);
		
		//Lets write a response
		$menu_text = "Please enter your oldPIN to proceed";
		$this->writeResponse($menu_text);
	}
	private function resetPinProcess(){
		//Lets reset the pin
		$pin1 = $this->requestString;
		// $menu_text = "Please enter your new PIN";
		// $this->writeResponse($menu_text);
		// $newpin=$this->requestString;
		
		if($this->user_session == null){
			$this->sessionError();
			return;
		}
		//do pin reset magic
		
		$mobile = $this->formatMobile($this->msisdn);
		// $mobile="0772093837";
		$employeei=new Employee();
		$employee = $employeei->getByMobile($mobile);
		if($employee == null){
			$this->writeResponse("Failed to find employee record based on mobile",true);
			return;
		}
		
		// $user = $this->user->find($employee->user_id);
		// if($user == null){
		// 	$this->writeResponse("Failed to find user record based on mobile",true);
		// 	return ;
		// }
		
		// $data["password"] = $pin;
		// $data["active"] = 1;
		$pini=new pin();
		$res=$pini->updatePin($mobile, $pin1);
		if($res==1)
		{
			$data["Active"]=1;
			$employeei->Activate($data, $mobile);
			$this->writeResponse("PIN has been changed successfully\r\n*. Back");
			return;
		}
		else
		{
		$this->writeResponse("Failed to update user PIN, please contact CreditPlus for help",true);
		}
		
		//we need to delete the session
		$ussd_session=new ussd_session();
		$data['deleted'] =1;
		

		$ussd_session->update($data,$this->transactionId);
		
		
	}
	private function resetPinValidate(){
		
		//Lets validate the PIN
		$mobile = $this->formatMobile($this->msisdn);
		$oldpin = $this->requestString;
		$pini=new pin();
		if($pini->validatePin($mobile,$oldpin)==0){
		
			$this->sessionErrorIncorrectPin();
			return;
		}
		$ussd_session=new ussd_session();
		$data['last_usercode'] = '00_04_00';
		
		$ussd_session->update($data,$this->transactionId);
		
		//Lets write a response
		$menu_text = "Please enter your new PIN";
		$this->writeResponse($menu_text);
	}
	private function getAdvancePinRequest(){
		//Lets update the session data
		$amount = $this->requestString;
		if(!is_numeric($amount))
		{
			$this->writeResponse("Invalid amount specified\r\nPlease specify a valid amount");
			return;
		}
			
		$ussd_session=new ussd_session();
		//Lets update the session information
		$data['last_usercode'] = '00_01_00';
		$data['data1'] = $amount;
		
		$ussd_session->update($data,$this->transactionId);
		
		//Lets add commas into the amount
		$english_amount = number_format($amount);
		
		//Lets write a response
		$menu_text = "Please enter your PIN to get advance of UGX".$english_amount;
		$this->writeResponse($menu_text);
	}

	private function getAdvanceProcess(){
		//Lets validate the PIN
		$pin3 = $this->requestString;
		
		if($this->user_session == null){
			$this->sessionError();
			return;
		}
		// Lets vaidate the PIN
		$pin6=new pin();
		$mobile = $this->formatMobile($this->msisdn);
			if($pin6->validatePin($mobile,$pin3)==0){
				// $this->writeResponse("The Pin You entered is wrong",true);
				$this->sessionErrorIncorrectPin();
				return;
			}
		
	
		$ussd_session=new ussd_session();
		$amount =$ussd_session->getdata1($this->transactionId);
		//Lets process the payment
		$this->processPayment($amount);
				
			
	}
	
	private function processPayment($amount)
	{
			
		$mobile = $this->formatMobile($this->msisdn);
		// $mobile="0772093837";
		$employeei=new Employee();
		$employee = $employeei->getByMobile($mobile);
		// $this->writeResponse($employee,true);
		if($employee == null){
			$this->writeResponse("Failed to find employee record based on mobile",true);
			return;
		}
            
			$employer = $employeei->getEmployerIdByMobile($mobile);
			// $this->writeResponse($employer,true);
            if($employer == null){
				$this->writeResponse("Employer not found, please contact CreditPlus for help",true);
				return;
			}
            //Lets check the status of the employer before proceeding
            /**
             * Employer Status
             *  0	-	Normal
             *  1	-	Processing payments
             *  2	-	Suspended
             * 
             * 
             */
            switch($employeei->employerStatus($mobile)){
                case 1:
                    $this->writeResponse("Employer is still processing pending payements",true);
                    return;
                case 2:
                    $this->writeResponse("Employer is suspended from Credit Plus platform",true);
					return;
            }
            
            //Lets get the platform settings
            // $cp_settings = $this->platform_settings->get_settings();
            
			// $service_fee = $cp_settings->service_fee;
			$service_fee = 390;
            
             //Lets validate before we save
             $payday = $employeei->getPayDay($mobile);
			//loan amount must not be greater than salary
			// $this->writeResponse($payday,true);
			$salary= $employeei->getSalaryByMobile($mobile);
			// $this->writeResponse($salary,true);
			if($amount >= $salary){
				$this->writeResponse("Cannot process payment because amount requested is greater than salary",true);
				return;
			}
			
            //Check the date of request compared to the payday
            // $processing_period = $cp_settings->reconciliation_period;
            /*$today = date('j');
            if($today > $payday ){
                //we need to check if employer account is allowed to make further transactions
                $this->form_validation->set_message('check_amount', 'Cannot process payment because of the request date');
                return FALSE;
            }*/
            //Check if he has previous loans
            // $loans = $this->loan->getActiveByEmployeeId($employee->id);
			$current_bal = 0;
        
	        // if(!empty($loans)){
	        //     foreach($loans as $loan)
	        //         $current_bal += $loan->amount_borrowed;
			// }
			$current_bal=$employeei->getTotalBorrowed($mobile);
			// $this->writeResponse($current_bal,true);
			if(($amount + $current_bal) >= $salary){
				$this->writeResponse("Cannot process payment because current balance would be greater than salary",true);
				return;
			}
			
			//we need to check if the amount requested is greater than the advance limit
			// $advance_limit_perc = $employer->advance_limit;
			$advance_limit = $employeei->advanceLimitAmount($mobile);
			// $this->writeResponse($advance_limit,true);
			if($amount > $advance_limit){
				$this->writeResponse("Requested advance is greater than advance limit of UGX".number_format($advance_limit),true);
				return;
			}
			
			if(($amount + $current_bal) > $advance_limit){
				$rec_amount = $advance_limit - $current_bal;
				$this->writeResponse("Requested advance is greater than advance limit, recommended amount is UGX".number_format($rec_amount),true);
				return;
			}
            
            
            $service_amount = ($amount + $service_fee);
			// $this->writeResponse($service_amount,true);
            // $this->writeResponse($service_amount,true);
            $network_fee = 0;
			$network = $this->checkNetwork($mobile);
			//    $this->writeResponse($network,true);
            // if($network == "airtel")
			// 	$network_fee = $cp_settings->airtel_fee;
			// else if($network == "mtn")
			// 	$network_fee = $cp_settings->mtn_fee;
			// else if($network == "africell")
			// 	$network_fee = $cp_settings->africell_fee;
			// else if($network == "utl")

			$cpsettings=new settings();
// $name=1;

				$network_fee = $cpsettings->getsendchargeByName($network);
			      $yo_charge =$cpsettings->getsendchargeByName("yo");
			$yo_amount = $amount + $network_fee + $yo_charge;	
			// $this->writeResponse($yo_amount,true);
			
            $data['amount_borrowed'] = $amount;
            $data['employee_id'] =$employeei->getIdByMobile($mobile);
            $data['employer_id'] = $employeei->getEmployerIdByMobile($mobile);
            $data['send_charge'] = $network_fee;
            $data['withdraw_charge'] = 0;
            $data['service_fee'] = $service_amount;
            // $data['total_amount_due'] = $amount + $service_amount;
                        
            
            //Lets process the payment
            // $this->load->library('payments/Yo');// time to call payment class

			$to = $this->formatMobileInternational256($this->msisdn);
			$yo=new Yo();
			// $xml_response=$yo->withdraw(1000, 256772093837, $narrative="helo this  \n this is just a test", $ref_text="");
			// echo $xml_response;
			// $this->writeResponse("inside yo",true);
			$code = $yo->withdraw($yo_amount, $to, $narrative="helo this  \n this is just a test", $ref_text="");
			// $this->writeResponse($code,true);
            //$code =0;
            //we need to analyse this code incase it shows an error
            
			$proceed = false;
			if($code == 0 || $code == 1 || $code == 6)
				$proceed = true;
			else
			{
				$this->writeResponse("Payment gateway cannot process request (error: $code)",true);
				return;
			}
            
            
            
            //Lets save the record
            // $advance_id = $this->loan->skip_validation(true)->insert($data);
            $advance_id=$employeei->insert($data);
            
            //Lets send an sms
			// $this->load->library('sms/Infobip');
			$infobip=new infobip();
		
			
			$to = $this->formatMobileInternational($this->msisdn);
			$msg = "Your advance of UGX ".number_format($amount)." has been processed with id ".$advance_id;
			$from="CreditPlus";
			$message=$infobip->sendsms($from, $to, $msg);
            
            //Lets write the end response            
            $this->writeResponse("Advance has been processed successfully",true);
            
            $ussd_session=new ussd_session();
            //we need to delete the session
			$ussd_session->delete($transactionId);
    
	}
	private function getAccountStatus(){
		$ussd_session=new ussd_session();
		//Lets update the session data
		$data['last_usercode'] = '00_02';
		
		$ussd_session->update($data,$this->transactionId);
		//Lets write a response
		$menu_text = "Please enter your PIN";
		$this->writeResponse($menu_text);
		
	}
	private function getAccountStatusProcess()
	{
		//Lets validate the PIN
		$pin = $this->requestString;
		
		
		if($this->user_session == null){
			$this->sessionError();
			return;
		}
		// $this->writeResponse("succes pin");
		//Lets vaidate the PIN
		$mobile = $this->formatMobile($this->msisdn);
		// $this->writeResponse($mobile);
		$pini=new pin();
		if($pini->validatePin($mobile,$pin)==0){
		
			$this->sessionErrorIncorrectPin();
			return;
		}
		

		
		$employeei=new Employee();
		$employee = $employeei->getByMobile($mobile);
	
		// $this->writeResponse($employee,true);
		if($employee == null){
			$this->writeResponse("Failed to find employee record based on mobile",true);
			return;
		}
		
		// $loans = $this->loan->getActiveByEmployeeId($employee->id);
		$current_bal = 0;
		
		// if(!empty($loans)){
		// 	foreach($loans as $loan)
			$current_bal= $employeei->getTotalBorrowed($mobile);
		// }
	

		
		$status ="unknown";
		$employer =$employeei->employerStatus($mobile);
		// $this->writeResponse("status");
		
			switch($employer){
				case 0:
					$status = "Inactive";
					break;
				case 1;
					$status = "Active";
					break;
				
			}
		
		
		//we need to check if the amount requested is greater than the advance limit
		// $advance_limit_perc = $employer->advance_limit;
		$advance_limit = $employeei->advanceLimitAmount($mobile);
		
		$summary = "Status: $status\r\n";
		
		$summary .= "Account Name: ".$employeei->getEmployeeName($mobile)."\r\n";
		$summary .= "Advance Limit: UGX".number_format($advance_limit)."\r\n";
		$summary .= "Advance Total: UGX".number_format($current_bal);
		$summary .= "\r\n*. Back";
			
		$this->writeResponse($summary);
		
		//we need to delete the session
		//$this->ussd_session->delete($this->user_session->id);
		
		
	}
	private function sessionError()
	{
		$this->writeResponse('Session error, please restart process',true);
				
	}
	private function sessionErrorIncorrectPin(){
		$this->writeResponse("Incorrect PIN, please re-enter your PIN");
				
	}

	private function getActiveAdvances()
	{
		$ussd_session=new ussd_session();
		//Lets update the session data
		// $data['last_usercode'] = '00_02';
		
	
		$data['last_usercode'] = '00_03';
		$ussd_session->update($data,$this->transactionId);
		
		// $this->ussd_session->update($this->user_session->id,$data);
		
		//Lets write a response
		$menu_text = "Please enter your PIN to proceed";
		$this->writeResponse($menu_text);
	}
	

	private function getActiveAdvancesProcess()
	{
		//Lets validate the PIN
	
		$pin = $this->requestString;
		
		
		if($this->user_session == null){
			$this->sessionError();
			return;
		}
		$mobile = $this->formatMobile($this->msisdn);
		
		$pini=new pin();
		if($pini->validatePin($mobile,$pin)==0){
		
			$this->sessionErrorIncorrectPin();
			return;
		}
		
		// $mobile = $this->formatMobile($this->msisdn);
		$employeei=new Employee();
		$employee = $employeei->getByMobile($mobile);
	
		// $this->writeResponse($employee,true);
		if($employee == null){
			$this->writeResponse("Failed to find employee record based on mobile",true);
			return;
		}
// to be clear

		// $user = $this->user->find($employee->user_id);
		// if($user == null){
		// 	$this->writeResponse("Failed to find user record based on mobile",true);
		// 	return ;
		// }
		
		// $loans = $this->loan->getActiveByEmployeeId($employee->id);
		$current_bal = 0;
	
		$summary = "Account Name: ".$employeei->getEmployeeName($mobile)."\r\n";
		
		$summary .= "Active Advances:\r\n";
	
		$loans=$employeei->getListBorrowed($mobile);
		// $this->writeResponse($loans);
		if(!empty($loans)){
			foreach($loans as $loan){
				$current_bal += $loan["amount_borrowed"];
				$summary .= "Id: ".$loan["id"]." Amount: ".number_format($loan["amount_borrowed"])." on ".$loan["created_on"]."\r\n";
			}
		}else{
			$summary .= "No advances found!\r\n";
		}
		$summary .= "--------------\r\n";
		$summary .= "Advance Total: UGX".number_format($current_bal);
		$summary .= "\r\n*. Back";
		
		$this->writeResponse($summary,true);
			
		//we need to delete the session
		//$this->ussd_session->delete($this->user_session->id);
		
		
	}


}

$process=New proccess();
$process->process();

// $menu_text = "Welcome to CreditPlus\r\n1. Request Advance\r\n2. Account Status\r\n3. Advance Statement\r\n4. Change PIN";
?>





















    
