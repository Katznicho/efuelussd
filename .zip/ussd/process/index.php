<?php

 

include("process.php");



//  function writeResponse($msg,$isend = false){
// 		$resp_msg = 'responseString='.urlencode($msg);
// 		 if($isend)
// 		 	$resp_msg .= '&action=end';
// 		 else
// 			$resp_msg .= '&action=request';
//          echo $resp_msg;
// 	}
     
//   writeResponse("Welcome to CreditPlus\r\nYour do not have an account \r\n please contact Credit plus",true);



?>