<?php


error_reporting(E_ALL);
ini_set('display_errors', 1);
class infobip
{


public function sendsms($from, $to, $msg)
{
$curl = curl_init();
// $to=256772093837;

curl_setopt_array($curl, array(
  CURLOPT_URL => "http://api.infobip.com/sms/1/text/single",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS => "{ \"from\":\"".$from."\", \"to\":[ \"".$to."\" ], \"text\":\"".$msg."\" }",
  CURLOPT_HTTPHEADER => array(
    "accept: application/json",
    "authorization:Basic Y3JlZGl0cGx1c2RldjpUZXN0MTIzNEA=",
    "content-type: application/json"
  ),
));

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
//   
return 0;
} else {
//   echo $response;
return $response;
}

}
}
// $infobip=new infobip();
// $from ="kalungi";
// $content=$infobip->sendsms($from,"256772093837","hello world");
// echo $content;
// $decodedcontent=json_decode($content);
// print_r($decodedcontent->messages[0]->to);




?>