<?php
class loan
{

    private $loanId;
    private $userId;
    private $db_name="loan";

public function advancceLimitAmount($limit,$salary)
{
    



}






}



?>